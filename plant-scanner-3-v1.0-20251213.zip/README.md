# 🌿 Plant Scanner 3 - تطبيق فحص النباتات بالذكاء الاصطناعي

تطبيق ويب ذكي للكشف عن أمراض النباتات من خلال تحليل الصور باستخدام نموذج تعلم آلي.

## ✨ المميزات

- 📸 واجهة ويب عربية جميلة لرفع الصور
- 🤖 نموذج ذكاء اصطناعي (CNN) مدرب على TensorFlow
- 📊 عرض النتائج مع نسب الثقة والتفاصيل
- 📱 تصميم متجاوب يعمل على جميع الأجهزة

## 🛠️ التقنيات المستخدمة

- **Backend:** Python, Flask, TensorFlow, Keras
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **Tools:** Git, GitHub Projects, Virtual Environment

## 🚀 كيفية التشغيل محلياً

### المتطلبات المسبقة
- Python 3.8 أو أعلى
- Git

### خطوات التثبيت

1. **استنساخ المشروع:**
```bash
git clone https://github.com/Abdullahreda1969/plant-scanner-3.git
cd plant-scanner-3

إنشاء-2 وتفعيل البيئة الافتراضية:

bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/Mac:
source .venv/bin/activate

3-تثبيت المتطلبات:

bash
pip install -r requirements.txt

تشغيل4- التطبيق:

bash
cd app
python app.py

فتح-5 المتصفح:

text
http://localhost:5000

📁 هيكل المشروع
text
plant-scanner-3/
├── app/                 # تطبيق Flask
│   ├── app.py          # التطبيق الرئيسي
│   └── uploads/        # الصور المرفوعة مؤقتاً
├── model/              # نماذج الذكاء الاصطناعي
│   ├── train.py        # نصيحة التدريب
│   └── plant_disease_model.keras
├── templates/          # قوالب HTML
│   └── index.html      # الواجهة الرئيسية
├── dataset/            # بيانات التدريب
├── static/             # ملفات ثابتة (CSS, JS)
└── requirements.txt    # متطلبات Python

🧪 اختبار النموذج
يمكنك اختبار النموذج مباشرة عبر الطرفية:

bash
curl -X POST -F "file=@dataset/healthy/h1.jpg" http://localhost:5000/upload

🐛 المشاكل الشائعة والحلول
1. "ModuleNotFoundError: No module named 'tensorflow'"
الحل: تأكد من تفعيل البيئة الافتراضية (يجب أن ترى (.venv) قبل سطر الأوامر)

2. "TemplateNotFound: index.html"
الحل: تأكد من وجود index.html في مجلد templates/ بجانب مجلد app/

3. "ERR_CONNECTION_REFUSED"
الحل: أعد تشغيل الخادم بـ python app.py من مجلد app/

📈 خطوات التطوير المستقبلية
استخدام مجموعة بيانات حقيقية (PlantVillage)

إضافة قاعدة بيانات لتسليل النتائج

تحسين دقة النموذج

نشر التطبيق على منصة سحابية

🤝 المساهمة في المشروع
Fork المشروع

إنشاء فرع للميزة الجديدة (git checkout -b feature/AmazingFeature)

Commit التغييرات (git commit -m 'Add some AmazingFeature')

Push إلى الفرع (git push origin feature/AmazingFeature)

فتح طلب دمج (Pull Request)

📄 الرخصة
هذا المشروع مرخص تحت رخصة MIT - انظر ملف LICENSE للتفاصيل.

👥 فريق التطوير
رئيس الفريق: عبدالله

المطورون: فريق plant-scanner-3

